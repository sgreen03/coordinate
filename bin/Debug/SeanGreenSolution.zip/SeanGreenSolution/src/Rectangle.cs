﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DepositionMaterial
{
    class Rectangle
    {
        float length, width;

        public void setLength(float length)
        {
            this.length = length;
        }

        public void setWidth(float width)
        {
            this.width = width;
        }

        public float getLength()
        {
            return this.length;
        }

        public float getWidth()
        {
            return this.width;
        }

    }
}
